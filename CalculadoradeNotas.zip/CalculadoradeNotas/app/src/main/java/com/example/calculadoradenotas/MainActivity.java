package com.example.calculadoradenotas;

import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText textInputNota1;
    EditText textInputNota2;
    EditText textInputNota3;
    TextView textView3;
    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textInputNota1 = (EditText) findViewById(R.id.txtNota1);
        textInputNota2 = (EditText) findViewById(R.id.txtNota2);
        textInputNota3 = (EditText) findViewById(R.id.txtNota3);
        textView3 = (TextView) findViewById(R.id.textView3);
        btnCalcular = (Button)findViewById(R.id.btnCalcular);
    }

    public void CalcularNota(View view) {
        Double nota1;
        Double nota2;
        Double nota3;
        Double Calculo;
        Double Media;


        nota1 = Double.parseDouble(textInputNota1.getText().toString());
        nota2 = Double.parseDouble(textInputNota2.getText().toString());
        nota3 = Double.parseDouble(textInputNota3.getText().toString());

        Media = (nota1*0.3)+(nota2*0.3)+(nota3*0.4);

        textView3.setText(Media.toString());
    }
}
